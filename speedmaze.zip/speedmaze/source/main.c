#include <3ds.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>

#define MAZE_WIDTH 49
#define MAZE_HEIGHT 27
#define MAX_LEVELS 10
#define PI 3.14159265358979323846
#define SAMPLE_RATE 32000

char maze[MAZE_HEIGHT][MAZE_WIDTH];
int player_x = 1;
int player_y = 1;

// --- GLOBALS FOR CONSOLES ---
PrintConsole topScreen, bottomScreen;

// --- SAVE DATA VARIABLES ---
double best_sectors[MAX_LEVELS];
double best_full = 999.99; 
double current_sectors[MAX_LEVELS];

// --- GHOST SYSTEM ---
#define MAX_MOVES 1500
typedef struct {
    u8 x, y;
    double time;
} MoveData;

MoveData current_path[MAX_LEVELS][MAX_MOVES];
int current_move_counts[MAX_LEVELS];

MoveData best_path[MAX_LEVELS][MAX_MOVES];
int best_move_counts[MAX_LEVELS];

bool show_ghost = true;
bool ghost_active = false;
int ghost_x = -1, ghost_y = -1;

// --- PARTICLE TRAIL ---
#define TRAIL_MAX 4
int trail_x[TRAIL_MAX];
int trail_y[TRAIL_MAX];
int trail_len = 0;
bool show_particles = true;

// --- AUDIO STRUCT ---
typedef struct {
    s16* buffer;
    u32 numSamples;
    ndspWaveBuf waveBuf;
} SoundEffect;

SoundEffect step_sfx;
SoundEffect win_sfx;

// Color Customization Arrays
int bg_colors[] = {41, 42, 43, 44, 45, 46, 47}; 
const char* color_names[] = {"RED", "GRN", "YLW", "BLU", "MAG", "CYN", "WHT"};

int wall_color = 1;  
int player_color = 0;

int dx[] = {0, 0, -2, 2};
int dy[] = {-2, 2, 0, 0};

// --- DRAWING HELPER ---
void draw_cell(int x, int y) {
    consoleSelect(&topScreen);
    printf("\x1b[%d;%dH", y + 1, x + 1);
    
    // Priority 1: Player
    if (x == player_x && y == player_y) {
        printf("\x1b[%dm \x1b[0m", bg_colors[player_color]);
    } 
    // Priority 2: Ghost
    else if (show_ghost && ghost_active && x == ghost_x && y == ghost_y) {
        printf("\x1b[43m\x1b[30mG\x1b[0m"); // Yellow background, black G
    } 
    // Priority 3 & 4: Trail & Environment
    else {
        bool in_trail = false;
        if (show_particles) {
            for (int i = 0; i < trail_len; i++) {
                if (trail_x[i] == x && trail_y[i] == y) {
                    printf("\x1b[%dm*\x1b[0m", bg_colors[player_color] - 10);
                    in_trail = true;
                    break;
                }
            }
        }
        
        if (!in_trail) {
            if (maze[y][x] == 'E') printf("\x1b[45mE\x1b[0m");
            else printf(" ");
        }
    }
}

// --- SAVE/LOAD FUNCTIONS ---
void load_save() {
    FILE* f = fopen("sdmc:/10maze_save.dat", "rb");
    
    memset(best_path, 0, sizeof(best_path));
    memset(best_move_counts, 0, sizeof(best_move_counts));

    if (f) {
        // Check file size to prevent reading garbage from an older save version
        fseek(f, 0, SEEK_END);
        long fsize = ftell(f);
        fseek(f, 0, SEEK_SET);

        fread(best_sectors, sizeof(double), MAX_LEVELS, f);
        fread(&best_full, sizeof(double), 1, f);
        
        // Only load ghost paths if the save file is large enough (new format)
        if (fsize > 1000) {
            fread(best_path, sizeof(MoveData), MAX_LEVELS * MAX_MOVES, f);
            fread(best_move_counts, sizeof(int), MAX_LEVELS, f);
        }
        fclose(f);
    } else {
        for (int i = 0; i < MAX_LEVELS; i++) best_sectors[i] = 999.99;
        best_full = 999.99;
    }
}

void save_game() {
    FILE* f = fopen("sdmc:/10maze_save.dat", "wb");
    if (f) {
        fwrite(best_sectors, sizeof(double), MAX_LEVELS, f);
        fwrite(&best_full, sizeof(double), 1, f);
        fwrite(best_path, sizeof(MoveData), MAX_LEVELS * MAX_MOVES, f);
        fwrite(best_move_counts, sizeof(int), MAX_LEVELS, f);
        fclose(f);
    }
}

// --- PROCEDURAL AUDIO GENERATION ---
void setup_channel(int channel) {
    ndspChnSetInterp(channel, NDSP_INTERP_LINEAR);
    ndspChnSetRate(channel, SAMPLE_RATE);
    ndspChnSetFormat(channel, NDSP_FORMAT_MONO_PCM16);
    float mix[12];
    for (int i=0; i<12; i++) mix[i] = 1.0f;
    ndspChnSetMix(channel, mix);
}

void generate_sounds() {
    ndspInit();
    ndspSetOutputMode(NDSP_OUTPUT_STEREO);
    setup_channel(0); 
    setup_channel(1); 

    step_sfx.numSamples = SAMPLE_RATE * 0.05;
    step_sfx.buffer = (s16*)linearAlloc(step_sfx.numSamples * sizeof(s16));
    
    for (u32 i = 0; i < step_sfx.numSamples; i++) {
        float t = (float)i / SAMPLE_RATE;
        float env = 1.0f - ((float)i / step_sfx.numSamples); 
        float freq = 400.0f - (250.0f * (t / 0.05f)); 
        step_sfx.buffer[i] = (s16)(4000.0f * sin(2.0f * PI * freq * t) * env);
    }
    DSP_FlushDataCache(step_sfx.buffer, step_sfx.numSamples * sizeof(s16));

    memset(&step_sfx.waveBuf, 0, sizeof(ndspWaveBuf));
    step_sfx.waveBuf.data_vaddr = step_sfx.buffer;
    step_sfx.waveBuf.nsamples = step_sfx.numSamples;
    step_sfx.waveBuf.looping = false;
    step_sfx.waveBuf.status = NDSP_WBUF_FREE;

    u32 note1_samples = SAMPLE_RATE * 0.15;
    u32 note2_samples = SAMPLE_RATE * 0.35;
    win_sfx.numSamples = note1_samples + note2_samples;
    win_sfx.buffer = (s16*)linearAlloc(win_sfx.numSamples * sizeof(s16));

    float freq1 = 523.25f; 
    float freq2 = 783.99f; 

    for (u32 i = 0; i < note1_samples; i++) {
        float t = (float)i / SAMPLE_RATE;
        float env = 1.0f - ((float)i / note1_samples); 
        win_sfx.buffer[i] = (s16)(20000.0f * sin(2.0f * PI * freq1 * t) * env);
    }
    for (u32 i = 0; i < note2_samples; i++) {
        float t = (float)i / SAMPLE_RATE;
        float env = 1.0f - ((float)i / note2_samples);
        win_sfx.buffer[note1_samples + i] = (s16)(20000.0f * sin(2.0f * PI * freq2 * t) * env);
    }
    DSP_FlushDataCache(win_sfx.buffer, win_sfx.numSamples * sizeof(s16));

    memset(&win_sfx.waveBuf, 0, sizeof(ndspWaveBuf));
    win_sfx.waveBuf.data_vaddr = win_sfx.buffer;
    win_sfx.waveBuf.nsamples = win_sfx.numSamples;
    win_sfx.waveBuf.looping = false;
    win_sfx.waveBuf.status = NDSP_WBUF_FREE;
}

// --- MAZE FUNCTIONS ---
void carve_maze(int x, int y) {
    maze[y][x] = ' ';
    
    int dirs[4] = {0, 1, 2, 3};
    for (int i = 0; i < 4; i++) {
        int r = rand() % 4;
        int temp = dirs[i];
        dirs[i] = dirs[r];
        dirs[r] = temp;
    }
    
    for (int i = 0; i < 4; i++) {
        int nx = x + dx[dirs[i]];
        int ny = y + dy[dirs[i]];
        
        if (nx > 0 && nx < MAZE_WIDTH - 1 && ny > 0 && ny < MAZE_HEIGHT - 1 && maze[ny][nx] == '#') {
            maze[y + dy[dirs[i]] / 2][x + dx[dirs[i]] / 2] = ' '; 
            carve_maze(nx, ny);
        }
    }
}

void draw_maze() {
    consoleSelect(&topScreen);
    printf("\x1b[0;0H"); 

    for (int y = 0; y < MAZE_HEIGHT; y++) {
        for (int x = 0; x < MAZE_WIDTH; x++) {
            if (maze[y][x] == '#') {
                printf("\x1b[%dm \x1b[0m", bg_colors[wall_color]);
            } else if (maze[y][x] == 'E') {
                printf("\x1b[45mE\x1b[0m"); 
            } else {
                printf(" "); 
            }
        }
        printf("\n");
    }
    draw_cell(player_x, player_y);
}

void generate_level(int level) {
    srand(1000 + level); 
    
    for (int y = 0; y < MAZE_HEIGHT; y++) {
        for (int x = 0; x < MAZE_WIDTH; x++) maze[y][x] = '#';
    }
    
    carve_maze(1, 1);
    maze[MAZE_HEIGHT - 2][MAZE_WIDTH - 2] = 'E'; 
    
    player_x = 1;
    player_y = 1;

    trail_len = 0;
    ghost_active = false;
    ghost_x = -1;
    ghost_y = -1;

    current_move_counts[level - 1] = 0;
    current_path[level - 1][0].x = 1;
    current_path[level - 1][0].y = 1;
    current_path[level - 1][0].time = 0.0;
    current_move_counts[level - 1] = 1;

    draw_maze();
}

int main(int argc, char **argv) {
    gfxInitDefault();
    
    consoleInit(GFX_TOP, &topScreen);
    consoleInit(GFX_BOTTOM, &bottomScreen);

    generate_sounds();
    load_save(); 

    int current_level = 1;
    bool timer_started = false;
    bool game_won = false;
    u64 level_start_time = 0;

    int move_cooldown = 0;
    const int MOVEMENT_SPEED = 4;

    for(int i=0; i<MAX_LEVELS; i++) current_sectors[i] = 0.0;

    generate_level(current_level);

    consoleSelect(&bottomScreen);
    printf("\x1b[0;0H"); 
    printf("========================================\n");
    printf("           10-MAZE SPEEDRUN             \n");
    printf("========================================\n\n");

    while (aptMainLoop()) {
        hidScanInput();
        u32 kDown = hidKeysDown();
        u32 kHeld = hidKeysHeld();

        if (kDown & KEY_START) break; 

        // --- INSTANT RESTART LOGIC ---
        if (kDown & KEY_SELECT) {
            current_level = 1;
            game_won = false;
            timer_started = false;
            move_cooldown = 0;
            
            for(int i=0; i<MAX_LEVELS; i++) current_sectors[i] = 0.0;
            ndspChnWaveBufClear(0);
            ndspChnWaveBufClear(1);
            generate_level(current_level);
        }

        // --- TOUCH SCREEN LOGIC ---
        if (kDown & KEY_TOUCH) {
            touchPosition touch;
            hidTouchRead(&touch);
            
            int tx = touch.px / 8;
            int ty = touch.py / 8;

            if (tx < 18) {
                if (ty >= 6 && ty <= 8) { 
                    wall_color = (wall_color + 1) % 7;
                    draw_maze(); 
                } 
                else if (ty >= 9 && ty <= 11) { 
                    player_color = (player_color + 1) % 7;
                    draw_cell(player_x, player_y);
                    for(int i=0; i<trail_len; i++) draw_cell(trail_x[i], trail_y[i]);
                }
                else if (ty >= 12 && ty <= 14) {
                    show_ghost = !show_ghost;
                    if (!show_ghost && ghost_active) {
                        int ox = ghost_x, oy = ghost_y;
                        ghost_active = false;
                        draw_cell(ox, oy); // Erases the ghost cleanly
                    }
                }
                else if (ty >= 15 && ty <= 17) {
                    show_particles = !show_particles;
                    if (!show_particles) {
                        // Clear existing trail visually, then reset logic
                        for(int i=0; i<trail_len; i++) {
                            int old_tx = trail_x[i];
                            int old_ty = trail_y[i];
                            trail_x[i] = -1; // Flag inactive
                            draw_cell(old_tx, old_ty); 
                        }
                        trail_len = 0;
                    }
                }
            }
        }

        double live_t = timer_started ? (osGetTime() - level_start_time) / 1000.0 : 0.0;

        // --- GHOST UPDATE LOGIC ---
        if (show_ghost && !game_won && best_move_counts[current_level - 1] > 0) {
            int g_idx = 0;
            while (g_idx < best_move_counts[current_level - 1] - 1 && best_path[current_level - 1][g_idx + 1].time <= live_t) {
                g_idx++;
            }
            
            int new_gx = best_path[current_level - 1][g_idx].x;
            int new_gy = best_path[current_level - 1][g_idx].y;

            if (new_gx != ghost_x || new_gy != ghost_y || !ghost_active) {
                int old_gx = ghost_x, old_gy = ghost_y;
                ghost_x = new_gx; 
                ghost_y = new_gy;
                ghost_active = true;

                if (old_gx != -1) draw_cell(old_gx, old_gy);
                draw_cell(ghost_x, ghost_y);
            }
        }

        // --- PLAYER MOVEMENT ---
        if (!game_won) {
            if (move_cooldown > 0) move_cooldown--;

            if (move_cooldown == 0) {
                int next_x = player_x;
                int next_y = player_y;

                if (kHeld & (KEY_UP | KEY_CPAD_UP))         next_y--;
                else if (kHeld & (KEY_DOWN | KEY_CPAD_DOWN))   next_y++;
                else if (kHeld & (KEY_LEFT | KEY_CPAD_LEFT))   next_x--;
                else if (kHeld & (KEY_RIGHT | KEY_CPAD_RIGHT)) next_x++;

                if (next_x != player_x || next_y != player_y) {
                    if (!timer_started) {
                        timer_started = true;
                        level_start_time = osGetTime();
                        live_t = 0.0;
                    }

                    if (maze[next_y][next_x] != '#') {
                        // --- UPDATE PARTICLE TRAIL ---
                        if (show_particles) {
                            for (int i = TRAIL_MAX - 1; i > 0; i--) {
                                trail_x[i] = trail_x[i-1];
                                trail_y[i] = trail_y[i-1];
                            }
                            trail_x[0] = player_x;
                            trail_y[0] = player_y;
                            if (trail_len < TRAIL_MAX) trail_len++;
                        } else {
                            trail_len = 0;
                        }

                        int old_px = player_x, old_py = player_y;
                        player_x = next_x; 
                        player_y = next_y;

                        // --- RECORD MOVE FOR GHOST ---
                        if (current_move_counts[current_level - 1] < MAX_MOVES) {
                            int idx = current_move_counts[current_level - 1];
                            current_path[current_level - 1][idx].x = player_x;
                            current_path[current_level - 1][idx].y = player_y;
                            current_path[current_level - 1][idx].time = live_t;
                            current_move_counts[current_level - 1]++;
                        }
                        
                        draw_cell(old_px, old_py);
                        draw_cell(player_x, player_y);
                        
                        if (show_particles && trail_len == TRAIL_MAX) {
                            draw_cell(trail_x[TRAIL_MAX-1], trail_y[TRAIL_MAX-1]); 
                        }

                        move_cooldown = MOVEMENT_SPEED;

                        // Play step sound
                        if (step_sfx.waveBuf.status == NDSP_WBUF_DONE || step_sfx.waveBuf.status == NDSP_WBUF_FREE) {
                            ndspChnWaveBufAdd(0, &step_sfx.waveBuf);
                        }

                        if (maze[player_y][player_x] == 'E') {
                            ndspChnWaveBufClear(1); 
                            ndspChnWaveBufAdd(1, &win_sfx.waveBuf);

                            double final_sector_time = (osGetTime() - level_start_time) / 1000.0;
                            current_sectors[current_level - 1] = final_sector_time;

                            bool new_record = false;

                            if (current_sectors[current_level - 1] < best_sectors[current_level - 1]) {
                                best_sectors[current_level - 1] = current_sectors[current_level - 1];
                                memcpy(best_path[current_level - 1], current_path[current_level - 1], sizeof(MoveData) * current_move_counts[current_level - 1]);
                                best_move_counts[current_level - 1] = current_move_counts[current_level - 1];
                                new_record = true;
                            }

                            current_level++;
                            move_cooldown = 15; 

                            if (current_level > MAX_LEVELS) {
                                game_won = true;
                                timer_started = false;
                                double current_full = 0.0;
                                
                                for (int i = 0; i < MAX_LEVELS; i++) current_full += current_sectors[i];
                                
                                if (current_full < best_full) {
                                    best_full = current_full;
                                    new_record = true;
                                }

                                if (new_record) save_game(); 

                            } else {
                                if (new_record) save_game(); 
                                generate_level(current_level);
                                level_start_time = osGetTime();
                            }
                        }
                    }
                }
            }
        }

        // --- SPLIT BOTTOM SCREEN UI ---
        consoleSelect(&bottomScreen);
        
        printf("\x1b[5;2H--- SETTINGS ---");
        printf("\x1b[7;2HWALL: \x1b[%dm %s \x1b[0m", bg_colors[wall_color], color_names[wall_color]);
        printf("\x1b[10;2HPLYR: \x1b[%dm %s \x1b[0m", bg_colors[player_color], color_names[player_color]);
        
        // Let the player know if there is NO DATA yet for the ghost
        if (best_move_counts[current_level - 1] == 0) {
            printf("\x1b[13;2HGHOST: \x1b[33mNO DATA\x1b[0m");
        } else if (show_ghost) {
            printf("\x1b[13;2HGHOST: \x1b[32mON     \x1b[0m");
        } else {
            printf("\x1b[13;2HGHOST: \x1b[31mOFF    \x1b[0m");
        }

        if (show_particles) printf("\x1b[15;2HTRAIL: \x1b[32mON \x1b[0m  ");
        else printf("\x1b[15;2HTRAIL: \x1b[31mOFF\x1b[0m  ");
        
        // Formatted to completely clear any stray overwritten characters
        printf("\x1b[17;2H> Tap to change <  ");

        double running_total = 0.0;
        printf("\x1b[19;2H---------------");

        printf("\x1b[5;20H| --- TIMES ---");
        
        for (int i = 0; i < MAX_LEVELS; i++) {
            printf("\x1b[%d;20H| Maze %-2d: ", 7 + i, i + 1); 

            if (i < current_level - 1) {
                double t = current_sectors[i];
                running_total += t;

                if (best_sectors[i] == 999.99 || t == best_sectors[i]) printf("\x1b[37m"); 
                else if (t < best_sectors[i]) printf("\x1b[32m"); 
                else printf("\x1b[31m"); 
                
                printf("%5.2f s\x1b[0m      ", t);

            } else if (i == current_level - 1 && !game_won) {
                running_total += live_t;

                if (best_sectors[i] == 999.99 || live_t == best_sectors[i]) printf("\x1b[37m"); 
                else if (live_t < best_sectors[i]) printf("\x1b[32m"); 
                else printf("\x1b[31m"); 
                
                printf("%5.2f s\x1b[0m <--  ", live_t);
            } else {
                printf("\x1b[37m--.-- s\x1b[0m      ");
            }
        }

        printf("\x1b[20;2HRUN : %.2f s  ", running_total);
        if (best_full == 999.99) {
            printf("\x1b[21;2HBEST: --.-- s  ");
        } else {
            printf("\x1b[21;2HBEST: \x1b[33m%.2f s\x1b[0m  ", best_full);
        }

        if (game_won) {
            printf("\x1b[25;5H\x1b[32mRUN COMPLETE!                  \x1b[0m   ");
        } else {
            printf("\x1b[25;5H                                  ");
        }
        
        printf("\x1b[26;5H[START=Exit]  [SELECT=Restart]    ");
        printf("\x1b[28;11H\x1b[35ma game by lartodor\x1b[0m          ");

        gfxFlushBuffers();
        gfxSwapBuffers();
        gspWaitForVBlank();
    }

    if (step_sfx.buffer) linearFree(step_sfx.buffer);
    if (win_sfx.buffer) linearFree(win_sfx.buffer);

    ndspExit();
    gfxExit();
    return 0;
}